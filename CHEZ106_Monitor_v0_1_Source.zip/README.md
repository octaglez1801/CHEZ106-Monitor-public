# CHEZ 106.1 Monitor v0.1
APK-pipeline test: stream player, alarm/vibration, manual contest-word field, SMS composer to 762-555.
Automatic spoken-word detection is not implemented yet.
