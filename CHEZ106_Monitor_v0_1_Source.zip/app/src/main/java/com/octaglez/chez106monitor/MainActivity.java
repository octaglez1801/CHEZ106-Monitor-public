package com.octaglez.chez106monitor;
import android.app.*; import android.os.*; import android.content.*; import android.media.*; import android.net.Uri; import android.widget.*;
public class MainActivity extends Activity {
 static final String STREAM="https://rogers-hls.leanstream.co/rogers/ott1061.stream/playlist.m3u8";
 MediaPlayer player; TextView status; EditText code;
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(36,48,36,36);
 TextView t=new TextView(this);t.setText("CHEZ 106.1 Monitor");t.setTextSize(28);r.addView(t); status=new TextView(this);status.setText("STOPPED");status.setTextSize(20);r.addView(status);
 Button s=new Button(this);s.setText("START STREAM");r.addView(s);Button x=new Button(this);x.setText("STOP");r.addView(x);Button a=new Button(this);a.setText("TEST ALARM");r.addView(a);
 code=new EditText(this);code.setHint("Detected / contest word");r.addView(code);Button m=new Button(this);m.setText("PREPARE TEXT → 762-555");r.addView(m);setContentView(r);
 s.setOnClickListener(v->startStream());x.setOnClickListener(v->stopStream());a.setOnClickListener(v->alarm());m.setOnClickListener(v->sms());}
 void startStream(){stopStream();status.setText("CONNECTING…");player=new MediaPlayer();try{player.setAudioStreamType(AudioManager.STREAM_MUSIC);player.setDataSource(STREAM);player.setOnPreparedListener(p->{p.start();status.setText("LISTENING TO CHEZ 106.1");});player.setOnErrorListener((p,w,e)->{status.setText("STREAM ERROR");return true;});player.prepareAsync();}catch(Exception e){status.setText("STREAM ERROR");}}
 void stopStream(){if(player!=null){try{player.stop();}catch(Exception e){}player.release();player=null;}if(status!=null)status.setText("STOPPED");}
 void alarm(){Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(1200,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(1200);new ToneGenerator(AudioManager.STREAM_ALARM,100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,1200);}
 void sms(){Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:762555"));i.putExtra("sms_body",code.getText().toString().trim());startActivity(i);}
 protected void onDestroy(){stopStream();super.onDestroy();}
}